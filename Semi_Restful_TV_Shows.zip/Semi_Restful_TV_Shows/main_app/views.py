from django.shortcuts import render, redirect
from django.contrib import messages

from .models import Shows
# Create your views here.

def update(request, show_id):
    errors = Shows.objects.validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
            return redirect('/')
    else:
        update = Shows.objects.get(id=show_id)
        update.title = request.POST['title']
        update.network = request.POST['network']
        update.release_date = request.POST['release_date']
        update.desc = request.POST['desc']
        update.save()
    return redirect('/')

def index(request):
    context = {
        'all_shows': Shows.objects.all()
    }
    return render(request, "index.html", context)


def add(request):
    return render(request, "add.html")


def create(request):
    errors = Shows.objects.validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
            return redirect('/add')
    if request.method == 'POST':
        Shows.objects.create(
            title = request.POST['title'],
            network = request.POST['network'],
            release_date = request.POST['release_date'],
            desc = request.POST['desc'],
        )
        return redirect('/')
    return redirect('add')


def edit(request, show_id):
    context = {
        'show': Shows.objects.get(id=show_id)
    }
    return render(request, "edit.html", context)


def show(request, show_id):
    context = {
        'show': Shows.objects.get(id=show_id)
    }
    return render(request, "info.html", context)


def delete(request, show_id):
    delete = Shows.objects.get(id=show_id)
    delete.delete()
    return redirect('/')
