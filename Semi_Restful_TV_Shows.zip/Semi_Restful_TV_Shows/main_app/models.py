from django.db import models

# Create your models here.


class ShowsManager(models.Manager):
    def validator(self, postData):
        errors = {}
        if len(postData['title']) < 1:
            errors["title"] = 'Show title cannot be blank'
        if len(postData['network']) < 1:
            errors["network"] = 'Show network cannot be blank'
            # if len(postData['release_date']) 
            # errors["release_date"] = 'Show description should be at least 5 characters'
        if len(postData['desc']) < 5:
            errors["desc"] = 'Show description should be at least 5 characters'
        return errors


class Shows(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=255)
    release_date = models.DateTimeField()
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ShowsManager()
